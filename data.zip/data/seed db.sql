--Brands
delete from Brands
insert into Brands(Name) values ('Gucci')
insert into Brands(Name) values ('Louis Voitton')
insert into Brands(Name) values ('Channel')
select * from Brands
-----------------------------------------------------
--Colors
delete from Colors
insert into Colors(Name) values ('Black')
insert into Colors(Name) values ('White')
insert into Colors(Name) values ('Blue')
select * from Colors
-----------------------------------------------------
--Images
delete from Images
--insert into Images(Url, Alt, Url1, Alt1, Url2, Alt2, Url3, Alt3, Url4, Alt4) values (Url, Alt, Url1, Alt1, Url2, Alt2, Url3, Alt3, Url4, Alt4)
insert into Images(Url, Alt, Url1, Alt1, Url2, Alt2, Url3, Alt3, Url4, Alt4) values ('https://picsum.photos/100/100', 'Alt', 'https://picsum.photos/200/200', 'Alt 1', 'https://picsum.photos/300/300', 'Alt 2', 'https://picsum.photos/400/400', 'Alt 3', 'https://picsum.photos/500/500', 'Alt 4')
insert into Images(Url, Alt, Url1, Alt1, Url2, Alt2, Url3, Alt3, Url4, Alt4) values ('https://picsum.photos/100/100', 'Alt', 'https://picsum.photos/200/200', 'Alt 1', 'https://picsum.photos/300/300', 'Alt 2', 'https://picsum.photos/400/400', 'Alt 3', 'https://picsum.photos/500/500', 'Alt 4')
insert into Images(Url, Alt, Url1, Alt1, Url2, Alt2, Url3, Alt3, Url4, Alt4) values ('https://picsum.photos/100/100', 'Alt', 'https://picsum.photos/200/200', 'Alt 1', 'https://picsum.photos/300/300', 'Alt 2', 'https://picsum.photos/400/400', 'Alt 3', 'https://picsum.photos/500/500', 'Alt 4')
select * from Images

-----------------------------------------------------
--Prices
delete from Prices
insert into Prices(Price, DiscountPrice) values(10, 5) 
insert into Prices(Price, DiscountPrice) values(20, 10) 
insert into Prices(Price, DiscountPrice) values(30, 15) 
insert into Prices(Price, DiscountPrice) values(40, 20) 
select * from Prices
-----------------------------------------------------
--ProductCategories
delete from ProductCategories
insert into ProductCategories(Category) values ('Category 1')
insert into ProductCategories(Category) values ('Category 2')
insert into ProductCategories(Category) values ('Category 3')
select * from ProductCategories
-----------------------------------------------------
--ProductDescriptions
delete from ProductDescriptions
insert into ProductDescriptions(ShortText, LongText) values ('Short text 1', 'Logng text 1')
insert into ProductDescriptions(ShortText, LongText) values ('Short text 2', 'Logng text 2')
insert into ProductDescriptions(ShortText, LongText) values ('Short text 3', 'Logng text 3')
insert into ProductDescriptions(ShortText, LongText) values ('Short text 4', 'Logng text 4')
select * from ProductDescriptions
-----------------------------------------------------
--ReleseYears
delete from ReleseYears
insert into ReleseYears(Year) values (2020)
insert into ReleseYears(Year) values (2021)
insert into ReleseYears(Year) values (2023)
select * from ReleseYears

-----------------------------------------------------
--Products
 delete from Products
--PriceId, BrandId, CategoryId, DescriptionId, ColorId, ImageId
DECLARE @SKU INT,  @PriceId INT , @BrandId INT , @CategoryId INT , @DescriptionId INT , @ColorId INT, @ImageId INT, @ImagesId INT,@ReleseYearId INT 
SELECT @SKU = 1
select @PriceId  = MAX(id) FROM Prices
select @BrandId  = MAX(id) FROM Brands
select @CategoryId  = MAX(id) FROM ProductCategories
select @DescriptionId  = MAX(id) FROM ProductDescriptions
select @ColorId  = MAX(id) FROM Colors
select @ImageId  = MAX(id) FROM Images
select @ImageId  = MAX(id) FROM Images
select @ImagesId  = MAX(id) FROM Images
select @ReleseYearId  = MAX(id) FROM ReleseYears

insert into Products(SKU, Name, PriceId, BrandId, CategoryId, DescriptionId, ColorId, ReleseYearId, ImageId, ImageName, ImagesId, IsActive, CreatedAt) values 
		    (@SKU, 'Product 1', @PriceId, @BrandId, @CategoryId, @DescriptionId, @ColorId,@ReleseYearId, @ImageId, 'Image name 1', @ImagesId,  1, GETDATE())


SET @SKU = @SKU +  1 
SET @PriceId = @PriceId - 1
SET @BrandId = @BrandId - 1
SET @CategoryId = @CategoryId - 1
SET @DescriptionId = @DescriptionId - 1
SET @ColorId = @ColorId - 1
SET @ImageId = @ImageId - 1
SET @ImagesId = @ImagesId - 1

SET @ReleseYearId = @ReleseYearId - 1
insert into Products(SKU, Name, PriceId, BrandId, CategoryId, DescriptionId, ColorId, ReleseYearId, ImageId, ImageName, ImagesId, IsActive, CreatedAt) values 
		    (@SKU, 'Product 2', @PriceId, @BrandId, @CategoryId, @DescriptionId, @ColorId,@ReleseYearId, @ImageId, 'Image name 1', @ImagesId,  1, GETDATE())

SET @SKU = @SKU + 1  

SET @PriceId = @PriceId - 1
SET @BrandId = @BrandId - 1
SET @CategoryId = @CategoryId - 1
SET @DescriptionId = @DescriptionId - 1
SET @ColorId = @ColorId - 1
SET @ImageId = @ImageId - 1
SET @ImagesId = @ImagesId - 1
SET @ReleseYearId = @ReleseYearId - 1
insert into Products(SKU, Name, PriceId, BrandId, CategoryId, DescriptionId, ColorId, ReleseYearId, ImageId, ImageName, ImagesId, IsActive, CreatedAt) values 
		    (@SKU, 'Product 3', @PriceId, @BrandId, @CategoryId, @DescriptionId, @ColorId,@ReleseYearId, @ImageId, 'Image name 1', @ImagesId,  1, GETDATE())
select * from Products


 SELECT [p].[SKU], [p].[BrandId], [p].[CategoryId], [p].[ColorId], [p].[CreatedAt], [p].[DescriptionId], [p].[ImageId], [p].[ImageName], [p].[ImagesId], [p].[IsActive], [p].[Name], [p].[PriceId], [p].[ReleseYearId], [p].[ReviewsId]
      FROM [Products] AS [p]