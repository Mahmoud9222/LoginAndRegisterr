﻿using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegisterr.Controllers
{
    public class ErrorController : Controller
    {
        public IActionResult AccessDenied()
        {
            return View();
        }
    }
}
