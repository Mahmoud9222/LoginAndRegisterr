﻿namespace LoginAndRegisterr.Models.Products
{
    public class ProductReviewsModel
    {
        public string PostBy { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;

    }
}
