﻿namespace LoginAndRegisterr.Models.Navigation
{
    public private MenuLinkModel
    {
        public string Controller { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}
