﻿using Microsoft.AspNetCore.Mvc;

namespace LoginAndRegisterr.Controllers
{
    public class SearchController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
