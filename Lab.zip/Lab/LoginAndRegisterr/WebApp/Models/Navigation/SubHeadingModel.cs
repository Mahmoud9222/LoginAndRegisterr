﻿namespace LoginAndRegisterr.Models.Navigation
{
    public class SubHeadingModel
    {
        public string Title { get; set; } = string.Empty;
        public string Subtitle { get; set; } = string.Empty;

    }
}
