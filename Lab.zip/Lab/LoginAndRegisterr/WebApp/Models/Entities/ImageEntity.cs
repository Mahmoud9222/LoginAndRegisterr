﻿namespace LoginAndRegisterr.Models.Entities
{
    public class ImageEntity
    {
        public int Id { get; set; }
        public string? Url { get; set; }
        public string? Alt { get; set; }
        public string? Url1 { get; set; }
        public string? Alt1 { get; set; }
        public string? Url2 { get; set; }
        public string? Alt2 { get; set; }
        public string? Url3 { get; set; }
        public string? Alt3 { get; set; }
        public string? Url4 { get; set; }
        public string? Alt4 { get; set; }

    }
}
