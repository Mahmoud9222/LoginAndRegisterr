﻿namespace LoginAndRegisterr.Models.Entities
{
    public class ReleseYearEntity
    {
        public int Id { get; set; }
        public int Year { get; set; }
    }
}

