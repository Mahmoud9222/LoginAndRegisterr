﻿namespace LoginAndRegisterr.Models.Entities
{
    public class SubscribesEntity
    {
        public int Id { get; set; }
        public string Email { get; set; } = string.Empty;
    }
}
